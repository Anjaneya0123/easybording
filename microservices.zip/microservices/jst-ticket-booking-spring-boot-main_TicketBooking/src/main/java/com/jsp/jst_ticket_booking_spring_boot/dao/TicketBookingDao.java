package com.jsp.jst_ticket_booking_spring_boot.dao;

import com.jsp.jst_ticket_booking_spring_boot.dto.TicketBooking;

public interface TicketBookingDao {

    TicketBooking saveTicketBookingDao(TicketBooking ticketBooking);


}
